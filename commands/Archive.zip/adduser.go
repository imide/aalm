package commands

import (
	"github.com/bwmarrin/discordgo"
	"github.com/imide/ualmiles/util/db"
	"log"
)

var AddUser = Commands{
	Name:        "adduser",
	Description: "adds a user to the database",
	Options:     createOptions([]discordgo.ApplicationCommandOptionType{discordgo.ApplicationCommandOptionUser}, []string{"user"}, []string{"the user to add to the database"}),
	Handler:     AddUserRun,
}

func AddUserRun(s *discordgo.Session, i *discordgo.InteractionCreate) {
	userId, robloxId := getUser(s, i)

	if isBloxlinkFailed(robloxId) {
		handleBloxlinkFailure(s, i)
		return
	}

	exists, err := db.Exists(robloxId)
	if err != nil || exists {
		embed := createEmbed("⚠️ | **Warning**", "You cannot add a user who already exists in the database.", 0xffcc4d)
		sendInteractionResponse(s, i, embed)
		return
	}

	confirmed := promptUserCreation(s, i)

	switch confirmed {
	case true:
		err := db.AddUser(robloxId)
		if err != nil {
			log.Println("Failed to add user to database: ", err)
			errorMessage := "Failed to add user to database: " + err.Error()
			embed := createEmbed("❌ | **Error**", errorMessage, 0xFF0000)
			sendFollowup(s, i, embed)
			return
		}
		embed := createEmbed("✅ | **Success**", "Successfully added user "+userId+" to the database.", 0x77b255)
		sendFollowup(s, i, embed)

	case false:
		embed := createEmbed("❌ | **Cancelled**", "User not added to the database.", 0xFF0000)
		sendFollowup(s, i, embed)
	}

}
