// File: commands/resetmiles.go
package commands

import (
	"github.com/bwmarrin/discordgo"
	"github.com/imide/ualmiles/util/db"
	"strconv"
)

// ResetMiles is a command that resets a selected user's miles to zero.
var ResetMiles = Commands{
	Name:        "resetmiles",
	Description: "resets the selected user's miles to zero",
	Options:     createOptions([]discordgo.ApplicationCommandOptionType{discordgo.ApplicationCommandOptionUser}, []string{"user"}, []string{"the user to reset miles for"}),
	Handler:     ResetMilesRun,
}

// ResetMilesRun implements the 'resetmiles' command. It fetches user data,
// checks if the user is verified with Bloxlink and exists in the database,
// then resets the user's miles to zero.
func ResetMilesRun(s *discordgo.Session, i *discordgo.InteractionCreate) {
	userId, robloxId := getUser(s, i)

	if isBloxlinkFailed(robloxId) {
		handleBloxlinkFailure(s, i)
		return
	}

	exists, err := db.Exists(robloxId)
	if err != nil || !exists {
		embed := createEmbed("⚠️ | **Warning**", "You cannot reset a user who does not exist in the database.", 0xffcc4d)
		sendInteractionResponse(s, i, embed)
		return
	}

	oldMiles, _ := db.GetMiles(robloxId)
	db.UpdateMiles(robloxId, 0, db.Replace)
	embed := createEmbed("✅ | **Success**", "Successfully reset user "+userId+"'s miles. Previous: "+strconv.FormatInt(oldMiles, 10)+" miles. Current: 0 miles.", 0x77b255)
	sendInteractionResponse(s, i, embed)
}
