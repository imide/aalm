// File: commands/getmiles.go
package commands

import (
	"github.com/bwmarrin/discordgo"
	"github.com/imide/ualmiles/util/db"
	"strconv"
)

// GetMiles is a command that retrieves the miles for a selected user.
var GetMiles = Commands{
	Name:        "getmiles",
	Description: "retrieves the miles for the selected user",
	Options:     createOptions([]discordgo.ApplicationCommandOptionType{discordgo.ApplicationCommandOptionUser}, []string{"user"}, []string{"the user to get miles for"}),
	Handler:     GetMilesRun,
}

// GetMilesRun implements the 'getmiles' command. It fetches user data,
// checks if the user is verified with Bloxlink and exists in the database,
// then retrieves and displays the user's miles.
func GetMilesRun(s *discordgo.Session, i *discordgo.InteractionCreate) {
	userId, robloxId := getUser(s, i)

	if isBloxlinkFailed(robloxId) {
		handleBloxlinkFailure(s, i)
		return
	}

	exists, err := db.Exists(robloxId)
	if err != nil || !exists {
		handleUserDoesNotExist(s, i)
		return
	}

	miles, _ := db.GetMiles(robloxId)
	embed := createEmbed("✅ | **Success**", "User "+userId+" has "+strconv.FormatInt(miles, 10)+" miles.", 0x77b255)
	sendInteractionResponse(s, i, embed)
}
