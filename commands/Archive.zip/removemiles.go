// File: commands/removemiles.go
package commands

import (
	"github.com/bwmarrin/discordgo"
	"github.com/imide/ualmiles/util/db"
	"strconv"
)

// RemoveMiles is a command that removes miles from a selected user's total.
var RemoveMiles = Commands{
	Name:        "removemiles",
	Description: "removes miles from the selected user's total",
	Options:     createOptions([]discordgo.ApplicationCommandOptionType{discordgo.ApplicationCommandOptionUser, discordgo.ApplicationCommandOptionInteger}, []string{"user", "miles"}, []string{"the user to remove miles from", "the amount of miles to remove"}),
	Handler:     RemoveMilesRun,
}

// RemoveMilesRun implements the 'removemiles' command. It fetches user and miles data,
// checks if the user is verified with Bloxlink and exists in the database,
// then removes the specified miles from the user's total.
func RemoveMilesRun(s *discordgo.Session, i *discordgo.InteractionCreate) {
	userId, robloxId := getUser(s, i)
	removeMiles := i.ApplicationCommandData().Options[1].IntValue()

	if isBloxlinkFailed(robloxId) {
		handleBloxlinkFailure(s, i)
		return
	}

	exists, err := db.Exists(robloxId)
	if err != nil || !exists {
		handleUserDoesNotExist(s, i)
		return
	}

	oldMiles, _ := db.GetMiles(robloxId)
	db.UpdateMiles(robloxId, removeMiles, db.Subtract)
	newMiles, _ := db.GetMiles(robloxId)
	embed := createEmbed("✅ | **Success**", "Successfully removed miles from user "+userId+". Previous: "+strconv.FormatInt(oldMiles, 10)+" miles. Current: "+strconv.FormatInt(newMiles, 10)+" miles.", 0x77b255)
	sendInteractionResponse(s, i, embed)
}
