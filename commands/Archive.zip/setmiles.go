// File: commands/setmiles.go
package commands

import (
	"github.com/bwmarrin/discordgo"
	"github.com/imide/ualmiles/util/db"
	"strconv"
)

// SetMiles is a command that sets the miles for a selected user.
var SetMiles = Commands{
	Name:        "setmiles",
	Description: "sets the miles for the selected user",
	Options:     createOptions([]discordgo.ApplicationCommandOptionType{discordgo.ApplicationCommandOptionUser, discordgo.ApplicationCommandOptionInteger}, []string{"user", "miles"}, []string{"the user to set miles for", "the amount of miles to set"}),
	Handler:     SetMilesRun,
}

// SetMilesRun implements the 'setmiles' command. It fetches user and miles data,
// checks if the user is verified with Bloxlink and exists in the database,
// then sets the specified miles to the user's total.
func SetMilesRun(s *discordgo.Session, i *discordgo.InteractionCreate) {
	userId, robloxId := getUser(s, i)
	newMiles := i.ApplicationCommandData().Options[1].IntValue()

	if isBloxlinkFailed(robloxId) {
		handleBloxlinkFailure(s, i)
		return
	}

	exists, err := db.Exists(robloxId)
	if err != nil || !exists {
		handleUserDoesNotExist(s, i)
		return
	}

	oldMiles, _ := db.GetMiles(robloxId)
	db.UpdateMiles(robloxId, newMiles, db.Replace)
	embed := createEmbed("✅ | **Success**", "Successfully set miles for user "+userId+". Previous: "+strconv.FormatInt(oldMiles, 10)+" miles. Current: "+strconv.FormatInt(newMiles, 10)+" miles.", 0x77b255)
	sendInteractionResponse(s, i, embed)
}
