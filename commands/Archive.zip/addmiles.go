// File: commands/addmiles.go
package commands

import (
	"github.com/bwmarrin/discordgo"
	"github.com/imide/ualmiles/util/db"
	"log"
	"strconv"
)

// AddMiles is a command that adds miles to a selected user's total.
var AddMiles = Commands{
	Name:        "addmiles",
	Description: "adds miles to the selected user's total",
	Options:     createOptions([]discordgo.ApplicationCommandOptionType{discordgo.ApplicationCommandOptionUser, discordgo.ApplicationCommandOptionInteger}, []string{"user", "miles"}, []string{"the user to add miles for", "the amount of miles to add"}),
	Handler:     AddMilesRun,
}

// AddMilesRun implements the 'addmiles' command. It fetches user and miles data,
// checks if the user is verified with Bloxlink and exists in the database,
// then adds the specified miles to the user's total.
func AddMilesRun(s *discordgo.Session, i *discordgo.InteractionCreate) {
	userId, robloxId := getUser(s, i)
	addMiles := i.ApplicationCommandData().Options[1].IntValue()

	if isBloxlinkFailed(robloxId) {
		handleBloxlinkFailure(s, i)
		return
	}

	exists, err := db.Exists(robloxId)
	if err != nil || !exists {
		handleUserDoesNotExist(s, i)
		return
	}

	oldMiles, err := db.GetMiles(robloxId)
	if err != nil {
		log.Println("Error getting miles:", err)
		embed := createEmbed("Error", "An unknown error occurred", 0xFF0000) // Red color for error
		sendInteractionResponse(s, i, embed)
		return
	}
	db.UpdateMiles(robloxId, addMiles, db.Add)
	newMiles, err := db.GetMiles(robloxId)
	if err != nil {
		log.Println("Error getting miles:", err)
		embed := createEmbed("Error", "An unknown error occurred", 0xFF0000) // Red color for error
		sendInteractionResponse(s, i, embed)
		return
	}
	embed := createEmbed("✅ | **Success**", "Successfully added miles to user "+userId+". Previous: "+strconv.FormatInt(oldMiles, 10)+" miles. Current: "+strconv.FormatInt(newMiles, 10)+" miles.", 0x77b255)
	sendInteractionResponse(s, i, embed)
}
